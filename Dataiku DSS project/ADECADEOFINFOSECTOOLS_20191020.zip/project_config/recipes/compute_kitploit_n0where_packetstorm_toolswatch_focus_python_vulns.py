# -*- coding: utf-8 -*-
import dataiku
import os
import datetime
import functools
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from concurrent import futures
import io
import json
import urllib.request
import tempfile
from safety import safety
import safety.util

'''
# Read recipe inputs
kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared")
kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared_df = kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

kitploit_n0where_packetstorm_toolswatch_focus_python_vulns_df = kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared_df # For this sample code, simply copy input to output


# Write recipe outputs
kitploit_n0where_packetstorm_toolswatch_focus_python_vulns = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatch_focus_python_vulns")
kitploit_n0where_packetstorm_toolswatch_focus_python_vulns.write_with_schema(kitploit_n0where_packetstorm_toolswatch_focus_python_vulns_df)
'''

def grab_db(tmpdirname):
    result = None
    
    insecure_json = urllib.request.urlopen('https://github.com/pyupio/safety-db/raw/master/data/insecure.json').read()
    insecure_json_full = urllib.request.urlopen('https://github.com/pyupio/safety-db/raw/master/data/insecure_full.json').read()
    
    result = json.loads(insecure_json_full)
    
    with open(os.path.join(tmpdirname, 'insecure.json'), 'wb') as fout:
        fout.write(insecure_json)
        
    with open(os.path.join(tmpdirname, 'insecure_full.json'), 'wb') as fout:
        fout.write(insecure_json_full)
    
    return result

def search_cve(db, pkg_name, vuln_id):
    result = None
    
    if pkg_name in db:
        current_pkg_vulns = db[pkg_name]
        
        for vuln in current_pkg_vulns:
            if 'id' in vuln:
                if vuln['id'] == "pyup.io-%s" % vuln_id:
                    if 'cve' in vuln:
                        result = vuln['cve']
                        
    return result

def enum_target(index, target, tmpdirname, db):
    result = []
    
    packages = list(safety.util.read_requirements(io.StringIO(target['requirements_txt'])))
    
    vulns = safety.safety.check(packages=packages, key="", db_mirror=tmpdirname, cached="", ignore_ids="", proxy={})
    for vuln in vulns:
        vuln_dict = vuln._asdict()
        
        cve = search_cve(db, vuln.name, vuln.vuln_id)
        if cve:
            vuln_dict['cve'] = cve
            
        result.append(json.dumps(vuln_dict))
        
    target['requirements_vuln'] = '__|__'.join(i for i in result)
    
    return target

def extract_information(workers, tmpdirname, db):
    focus_github_python_df = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_python_prepared").get_dataframe()
    
    # just few to test
    #targets = focus_github_python_df.iloc[0:5]
    
    targets = focus_github_python_df
    
    focus_github_python_vulns = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatch_focus_python_vulns")
    
    schema = [{'name': 'tool_link', 'type': 'string'},
              {'name': 'tool_link_host', 'type': 'string'},
              {'name': 'tool_link_path', 'type': 'string'},
              {'name': 'requirements_txt', 'type': 'string'},
              {'name': 'requirements_txt_no_version', 'type': 'string'},
              {'name': 'requirements_vuln', 'type': 'string'}
             ]
    
    focus_github_python_vulns.write_schema(schema)
    
    with futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futs = [
            (target, executor.submit(functools.partial(enum_target, index, target, tmpdirname, db)))
            for index, target in targets.iterrows()
        ]
        
        writer = focus_github_python_vulns.get_writer()
        
        for target, fut in futs:
            try:
                result = fut.result()
                if result is not None:
                    writer.write_row_dict(result)
            except:
                pass
        writer.close()
    
    return None

with tempfile.TemporaryDirectory() as tmpdirname:
    workers = 8
    db = grab_db(tmpdirname)
    extract_information(workers, tmpdirname, db)