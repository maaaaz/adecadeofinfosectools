# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
import requests
import re
import functools
import datetime
from dataiku import pandasutils as pdu
from concurrent import futures
from lxml.html.soupparser import fromstring


def grab_number_of_pages():
    result = None
    p_page = re.compile('Page 1 of (?P<pages_number>[\d]*)')
    data = requests.get('https://packetstormsecurity.com/files/tags/tool').text
    
    page_number = p_page.search(data)
    if page_number:
        result = page_number.group('pages_number')
    
    return int(result)

def enum_target(target):
    result = []
    url_base = 'https://packetstormsecurity.com'
    url = 'https://packetstormsecurity.com/files/tags/tool/page%s/' % target
    root = fromstring(requests.get(url).text)
    
    trs = root.findall('.//dl[@class = "file"]')
    for entry in trs:
        current_tool = {}
        
        current_tool['name'] = entry.xpath('string(dt/a)')
        current_tool['href'] = url_base + entry.xpath('string(dt/a/@href)')
        current_tool['size'] = entry.xpath('string(dt/a/@title)').replace('Size:','').strip()
        current_tool['publication_date'] = datetime.datetime.strptime(entry.xpath('string(dd[1]/a)'), '%b %d, %Y')
        
        refer = entry.xpath('string(dd[@class="refer"])')
        p_authors_and_site = re.compile('Authored by (?P<authors>.*) [|] Site (?P<site>.*)').search(refer)
        if p_authors_and_site:
            current_tool['author'] = p_authors_and_site.group('authors')
            current_tool['download_site'] = p_authors_and_site.group('site')
        
        if 'download_site' in current_tool.keys():
            current_tool['download_link'] = entry.xpath('string(dd[@class="refer"]/a[last()]/@href)')
        
        current_tool['description'] = entry.xpath('string(dd[3]/p)')
        current_tool['md5'] = entry.xpath('string(dd[@class="md5"]/code)')
        current_tool['download_from_packetstorm'] = url_base + entry.xpath('string(dd[@class="act-links"]/a/@href)')
        
        result.append(current_tool)
    
    return target, result

def extract_information(workers):
    number_of_pages = grab_number_of_pages()
    
    targets = range(1, number_of_pages + 1)
    
    # just 4 pages for testing before grabbing everything
    #targets = range(1,5)
    
    packetstorm_tools = dataiku.Dataset("packetstorm_tools")
    schema = [{'name': 'name', 'type': 'string'},
              {'name': 'size', 'type': 'string'},
              {'name': 'publication_date', 'type': 'string'},
              {'name': 'author', 'type': 'string'},
              {'name': 'download_site', 'type': 'string'},
              {'name': 'download_link', 'type': 'string'},
              {'name': 'description', 'type': 'string'},
              {'name': 'md5', 'type': 'string'},
              {'name': 'download_from_packetstorm', 'type': 'string'},
              {'name': 'href', 'type': 'string'}
             ]
    packetstorm_tools.write_schema(schema)
    
    results = {}

    with futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futs = [
            (target, executor.submit(functools.partial(enum_target, target)))
            for target in targets
        ]
        
        writer = packetstorm_tools.get_writer()
        
        for target, fut in futs:
            page_number, tool_list = fut.result()
            for tool in tool_list:
                writer.write_row_dict(tool)
            
        writer.close()  
    
    return None

workers = 10
extract_information(workers)