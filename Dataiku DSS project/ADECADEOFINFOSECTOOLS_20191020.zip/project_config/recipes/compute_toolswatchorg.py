# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
import requests
import re
import functools
import datetime
from dataiku import pandasutils as pdu
from concurrent import futures
from lxml.html.soupparser import fromstring


def grab_list_of_pages(years):
    result = []
    url_base = 'https://www.toolswatch.org/'
    
    for year in years:
        url = url_base + str(year)
        root = fromstring(requests.get(url).text)
        
        trs = root.findall(".//div[@class = 'pagination']/a[last()]")
        if len(trs) == 1:
            number_of_pages = trs[0].xpath('string(@href)').replace(url + "/page/","").replace('/','')

            print("year %s, # of pages %s" % (year, number_of_pages))

            for page in range(1, int(number_of_pages) + 1):
                result.append(url + "/page/%s/" % str(page))
        
        elif len(trs) == 0:
            print("year %s, # of pages %s" % (year, 1))
            result.append(url + "/page/1/")
            
    
    return result

def enum_target(target):
    result = []
    root = fromstring(requests.get(target).text)
    
    trs = root.findall('.//article/div[@class = "omc-blog-two-text"]')
    for entry in trs:
        current_tool = {}
        
        name = entry.xpath('string(h2)')
        current_tool['name'] = name.replace('released', '').replace('Released', '')
        
        date = entry.xpath('string(p[@class="omc-blog-two-date"])')
        p_date = re.compile('(?P<date>.*) [|].*').search(date)
        if p_date:
            current_tool['publication_date'] = datetime.datetime.strptime(re.sub(r'(\d)(st|nd|rd|th)', r'\1', p_date.group('date')), '%B %d, %Y')
        
        current_tool['href'] = entry.xpath('string(h2/a/@href)')
        
        current_tool['description'] = entry.xpath('string()').replace(date, '').replace(name,'').strip()
        
        result.append(current_tool)
    
    return target, result

def extract_information(workers):
    years = range(2010,2020)
    
    # few years just to test
    #years = range(2010,2011)
    
    targets = grab_list_of_pages(years)
    
    toolswatchorg = dataiku.Dataset("toolswatchorg")
    schema = [{'name': 'name', 'type': 'string'},
              {'name': 'publication_date', 'type': 'string'},
              {'name': 'description', 'type': 'string'},
              {'name': 'href', 'type': 'string'}
             ]
    toolswatchorg.write_schema(schema)

    with futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futs = [
            (target, executor.submit(functools.partial(enum_target, target)))
            for target in targets
        ]
        
        writer = toolswatchorg.get_writer()
        
        for target, fut in futs:
            page_number, tool_list = fut.result()
            for tool in tool_list:
                writer.write_row_dict(tool)
        writer.close()  
    
    return None

workers = 8
extract_information(workers)