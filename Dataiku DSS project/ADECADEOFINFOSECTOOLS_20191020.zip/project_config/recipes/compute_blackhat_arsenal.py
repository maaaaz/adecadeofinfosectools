# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
import requests
import re
import functools
import datetime
from dataiku import pandasutils as pdu
from github import Github


def extract_matching_pattern(regex, group_name, md):
    result = ''
    if regex.search(md):
        result = regex.search(md).group(group_name).strip()
    
    return result

def parse_markdown_template(md):
    p_name = re.compile('#(?P<name>.*?)[#]+ Description', re.S | re.I)
    p_description = re.compile('# Description(?P<description>.*?)#', re.S | re.I)
    p_categories = re.compile('# Categories(?P<categories>.*?)#', re.S | re.I)
    p_sessions = re.compile('# Black.*Sessions(?P<sessions>.*?)#', re.S | re.I)
    p_badge = re.compile('arsenal/(.*?)\.svg?', re.I)
    p_code = re.compile('# Code(?P<code>.*?)#', re.S | re.I)
    
    # trying to decode as utf-8
    md = md.decode('utf-8', 'ignore')
    
    name = extract_matching_pattern(p_name, 'name', md).replace('\n', '')
    description = extract_matching_pattern(p_description, 'description', md).replace('\n', '')
    categories = extract_matching_pattern(p_categories, 'categories', md)
    
    sessions = extract_matching_pattern(p_sessions, 'sessions', md).replace('\n', '')
    
    badge = p_badge.findall(sessions)
    if badge:
        badge = " ".join(badge)
    else:
        badge = ''
    
    code = extract_matching_pattern(p_code, 'code', md)
    
    return name, description, categories, badge, code


def grab_list_of_tools(repo):
    contents = repo.get_contents("")
    buffer = contents.copy()
            
    while len(contents) > 1:
        file_content = contents.pop(0)
        if file_content.type == "dir":
            contents.extend(repo.get_contents(file_content.path))
            buffer.extend(repo.get_contents(file_content.path))
    
    result = []
    for content in buffer:
        current_tool = {}
        if (content.type == "file") and (content.path.endswith('.md')) and ("README.md" not in content.path) and ("tool_name.md" not in content.path):
            category, internal_name = content.path.split('/', 1)
            current_tool['tool_category_by_arsenal'] = category
            
            current_tool['tool_name'], \
            current_tool['tool_description'], \
            current_tool['tool_categories'], \
            current_tool['tool_sessions'], \
            current_tool['tool_code'] = parse_markdown_template(content.decoded_content)
            result.append(current_tool)
    
    return result
            

def extract_information():
    
    g = Github(dataiku.get_custom_variables()["github_username_1"], dataiku.get_custom_variables()["github_password"])
    repo = g.get_repo("toolswatch/blackhat-arsenal-tools")
    
    tool_list = grab_list_of_tools(repo)
    
    blackhat_arsenal = dataiku.Dataset("blackhat_arsenal")

    schema = [{'name': 'tool_category_by_arsenal', 'type': 'string'},
              {'name': 'tool_name', 'type': 'string'},
              {'name': 'tool_description', 'type': 'string'},
              {'name': 'tool_categories', 'type': 'string'},
              {'name': 'tool_sessions', 'type': 'string'},
              {'name': 'tool_code', 'type': 'string'}]
    
    blackhat_arsenal.write_schema(schema)
    
    writer = blackhat_arsenal.get_writer()
    for tool in tool_list:
        writer.write_row_dict(tool)
    writer.close()
    
    return None

extract_information()