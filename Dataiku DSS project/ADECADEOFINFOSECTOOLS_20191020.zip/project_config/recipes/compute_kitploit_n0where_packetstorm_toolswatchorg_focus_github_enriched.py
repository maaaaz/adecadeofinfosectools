# -*- coding: utf-8 -*-
import dataiku
import re
import datetime
import functools
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from concurrent import futures
import github
import random

'''
# Read recipe inputs
kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct")
kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct_df = kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched_df = kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct_df # For this sample code, simply copy input to output


# Write recipe outputs
kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched")
kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched.write_with_schema(kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched_df)
'''

def enum_target(index, target):
    account = dataiku.get_custom_variables()["github_username_%s" % random.randint(1,12)]
    g = github.Github(account, dataiku.get_custom_variables()["github_password"])
    
    try:
        print("[+] %s | index %s | target: %s" % (account, index, target['tool_link']))
        repo = g.get_repo("/".join(target['tool_link_path'].strip('/').split('/')[:2]))
    
    except github.GithubException as e:
        if e.status == 403:
            print("[!] Github rate limit reached | target %s" % target['tool_link'])
        return None
        
    target['stars_count'] = repo.stargazers_count
    target['forks_count'] = repo.forks_count
    target['watchers_count'] = repo.watchers_count
    try:
        target['releases_count'] = repo.get_releases().totalCount
    except:
        pass
    
    target['size_KB'] = repo.size
    
    commits = repo.get_commits()
    target['commit_total_number'] = commits.totalCount
    last_commit_date = commits[0].commit.committer.date
    first_commit_date = commits.reversed[0].commit.committer.date
    maintenance_period = last_commit_date - first_commit_date
    
    target['last_commit_date'] = last_commit_date.isoformat()
    target['first_commit_date'] = first_commit_date.isoformat()
    target['maintenance_period_days'] =  maintenance_period.days
    
    per_year = range(2011,2020)
    start_year = 2010
    for year in per_year:
        since_year = datetime.datetime.strptime(str(start_year), "%Y") 
        until_year = datetime.datetime.strptime(str(year), "%Y")
        target['commit_number_%s_%s' % (start_year, year)] = repo.get_commits(since=since_year, until=until_year).totalCount
        start_year = year
    
    
    target['issues_all_count'] = repo.get_issues(state='all').totalCount
    target['issues_open_count'] = repo.get_issues(state='open').totalCount
    target['issues_closed_count'] = target['issues_all_count'] - target['issues_open_count']

    target['pr_all_count'] = repo.get_pulls(state='all').totalCount
    target['pr_open_count'] = repo.get_pulls(state='open').totalCount
    target['pr_closed_count'] = target['pr_all_count'] - target['pr_open_count']
    
    target['languages'] = repo.get_languages()
    
    
    try:
        requirements_txt = repo.get_contents("requirements.txt")
        if requirements_txt and (requirements_txt.type == "file"):
            requirements_txt_content = requirements_txt.decoded_content
            target['requirements_txt'] = requirements_txt_content.decode('utf-8', 'ignore')
    
    except github.GithubException:
        pass
    
    target['git_url'] = repo.git_url
    
    return target

def extract_information(workers):
    focus_github_distinct_df = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_distinct").get_dataframe()
    
    targets = focus_github_distinct_df 
    
    # just few to test
    #targets = focus_github_distinct_df.iloc[0:5]
    
    focus_github_enriched = dataiku.Dataset("kitploit_n0where_packetstorm_toolswatchorg_focus_github_enriched")
    
    schema = [{'name': 'tool_link', 'type': 'string'},
              {'name': 'tool_link_host', 'type': 'string'},
              {'name': 'tool_link_path', 'type': 'string'},
              {'name': 'stars_count', 'type': 'string'},
              {'name': 'forks_count', 'type': 'string'},
              {'name': 'watchers_count', 'type': 'string'},
              {'name': 'releases_count', 'type': 'string'},
              {'name': 'size_KB', 'type': 'string'},
              {'name': 'commit_total_number', 'type': 'string'},
              {'name': 'last_commit_date', 'type': 'string'},
              {'name': 'first_commit_date', 'type': 'string'},
              {'name': 'maintenance_period_days', 'type': 'string'},
              {'name': 'commit_number_2010_2011', 'type': 'string'},
              {'name': 'commit_number_2011_2012', 'type': 'string'},
              {'name': 'commit_number_2012_2013', 'type': 'string'},
              {'name': 'commit_number_2013_2014', 'type': 'string'},
              {'name': 'commit_number_2014_2015', 'type': 'string'},
              {'name': 'commit_number_2015_2016', 'type': 'string'},
              {'name': 'commit_number_2016_2017', 'type': 'string'},
              {'name': 'commit_number_2017_2018', 'type': 'string'},
              {'name': 'commit_number_2018_2019', 'type': 'string'},
              {'name': 'issues_all_count', 'type': 'string'},
              {'name': 'issues_open_count', 'type': 'string'},
              {'name': 'issues_closed_count', 'type': 'string'},
              {'name': 'pr_all_count', 'type': 'string'},
              {'name': 'pr_open_count', 'type': 'string'},
              {'name': 'pr_closed_count', 'type': 'string'},
              {'name': 'languages', 'type': 'string'},
              {'name': 'requirements_txt', 'type': 'string'}
             ]
    focus_github_enriched.write_schema(schema)
    
    
    with futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futs = [
            (target, executor.submit(functools.partial(enum_target, index, target)))
            for index, target in targets.iterrows()
        ]
        
        writer = focus_github_enriched.get_writer()
        
        for target, fut in futs:
            try:
                result = fut.result()
                if result is not None:
                    writer.write_row_dict(result)
            except:
                pass
        writer.close()
    
    return None

workers = 8
extract_information(workers)